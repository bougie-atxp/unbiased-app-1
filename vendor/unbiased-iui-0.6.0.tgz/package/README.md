# unbiased-iui

Versioned intelligent UI components and their agent-facing catalogue for Unbiased.

This repository owns the React implementation, input schema, interaction contract, and examples for each component. The agent sees the generated catalogue, not React source. The app bundles a pinned package version; a remote catalogue is metadata, never executable code.

## Components

The agent-facing catalogue includes composable `PaletteScene`, `Scene`, `Grid`, `Timeline`, `Milestone`, `Sequence`, `SequenceSlide`, `ImageAsset`, `StateScope`, `Slider`, `StateScene`, `StateView`, and `StateCase` components plus a curated set from OpenUI 0.17.0: `Stack`, `TextContent`, `Callout`, `Steps`, `StepsItem`, `Table`, `Col`, `BarChart`, `LineChart`, `Series`, and `Separator`. Upstream components are imported from `@openuidev/react-ui`, not copied. Their OpenUI definitions drive both the runtime library and the generated catalogue. A new upstream version must be deliberately pinned, tested, and regenerated.

The first set focuses on explanations and read-only data. `StateScope` holds a local numeric value; `Slider` changes it, `StateScene` interpolates matching vector shapes between keyframes, and each `StateView` displays the first `StateCase` whose inclusive range contains the rounded value. An optional `StateScene.orbit` moves one circle along an elliptical path between keyframes, using the visible ellipse's center and radii, rather than cutting across it. This never invokes a host action or sends a message. Cover the entire range without overlaps; for continuous illustrations, include keyframes at both endpoints. The gallery includes a Moon example with tenths-of-a-day scrubbing. General-purpose `Card` and `Tabs` currently expand into very large schemas, and input/action components need a host action policy, so they are not yet in the agent-facing catalogue.

### Guided explainer

`Sequence` presents 2-12 navigable slides. Each `SequenceSlide` can contain a vector `Scene`, an approved `ImageAsset`, text, charts, diagrams, or callouts. `Scene` supplies bounded SVG shapes, colors, and reduced-motion-aware animation presets. `ImageAsset` accepts only an asset ID; the host must resolve it through `IUIAssetProvider`, so model-supplied URLs never become network requests. Hosts should list available IDs in their agent instructions and omit image usage when none are available.

`Grid` arranges two or three components in responsive columns and stacks them when the chat pane is narrow. `Timeline` displays 2-12 `Milestone` events with short descriptions and optional accent colors. The gallery combines both with a `Scene` for an Odyssey example.

### Curated palettes

For new illustrations, `PaletteScene` takes a palette ID and semantic shape colors (`background`, `surface`, `primary`, `secondary`, `accent`, `text`, `muted`, `outline`) instead of model-authored hex codes. `Scene` remains available for existing messages and precision artwork. New palette choices follow the five-color combinations in [12&28 Creative Studio's article](https://www.twelveandtwentyeight.com/blog/10-aesthetic-color-palettes):

| ID | Mood |
| --- | --- |
| `blue` | light, cool, clear |
| `green` | light, earthy, grounded |
| `red` | light, warm, confident |
| `yellow` | dark, bright, energetic |
| `orange` | light, warm, inviting |
| `purple` | light, cool, imaginative |
| `pink` | light, soft, playful |
| `white` | light, minimal, crisp |
| `black` | dark, minimal, composed |
| `brown` | light, earthy, classic |

Each palette retains its five source swatches in the article's order. Text and semantic accents are adjusted toward black or white only when needed to meet minimum contrast on the chosen background; not every resolved role is an unmodified source swatch. The six earlier palette IDs remain accepted as aliases for saved visuals, but are not offered as new choices. `HotspotVisual` inherits the palette accent when its visual is a `PaletteScene`. Palette selection controls color only: it does not prevent shape overlap or make an illustration recognizable on its own.

`ChoiceGroup` switches among 2-5 `ChoiceOption` views without invoking a host action. `HotspotVisual` places 1-8 keyboard-accessible `Hotspot` annotations on a `Scene` or host-approved `ImageAsset`. Both keep their state local to the visual. The gallery combines them in a solar/lunar eclipse explainer.

`IUIReveal` is a host-side, dependency-free entrance primitive with `none`, `fade`, `rise`, and `scale` variants. `Sequence` uses it when a slide changes and exposes an optional `transition` argument to the agent (default `rise`). Effects last 220 ms, move at most 8 px or scale from 98.5%, and are disabled by `prefers-reduced-motion`. The gallery's Dune sequence exercises `fade` through the same OpenUI renderer used by the app. This is an original Unbiased component, not React Bits code.

The older `GuidedExplainer` stays in the runtime library for existing messages but is no longer in the agent-facing catalogue or spec.

`IUIScrollRail` is a host-side navigation component for overflowing tabs and step strips. It retains native scrolling and keyboard behavior while applying the shared, low-contrast Unbiased scrollbar treatment; it is not an agent-facing content component.

```tsx
import { Renderer } from "@openuidev/react-lang";
import { IUIAssetProvider } from "@unbiased/iui";
import { iuiOpenUILibrary } from "@unbiased/iui/openui";
import "@unbiased/iui/styles.css";

<IUIAssetProvider resolveAsset={(id) => approvedAssets[id]}>
  <Renderer response={openuiSource} library={iuiOpenUILibrary} />
</IUIAssetProvider>
```

`@unbiased/iui/openui` exports an OpenUI `defineComponent` adapter and a curated library for OpenUI Lang. `Stack` is its root so components can be combined. The base React component and Zod schema do not depend on OpenUI's renderer. To render OpenUI Lang, wrap the host `Renderer` in `.iui-openui` and import `@unbiased/iui/openui-styles.css`; the stylesheet imports OpenUI's upstream styles and scopes Unbiased's dark tokens to that wrapper. The desktop app bundles this library, registers its own sandboxed visual components alongside it, and uses one OpenUI renderer for visual responses.

## Catalogue contract

`src/openui-standard.ts` selects the upstream definitions and records component guidance. `src/catalogue.ts` adds the local components. `catalogue/components.json` and `catalogue/openui-spec.json` are generated from the agent-facing library, while the runtime library also includes the legacy component. The app gives the agent all component signatures and descriptions from the bundled spec. A chart or table needs its dependent `Series` or `Col` definition too.

```sh
npm install
npm run catalogue:build
npm run verify
npm run dev
```

The gallery runs at `http://127.0.0.1:4173`. `catalogue:verify` fails if the committed JSON differs from the source. A future remotely fetched catalogue should be signed and last-good cached, following the connectors catalogue pattern; this first version is bundled and does not claim remote-update trust.

The gallery uses three Unsplash photographs only as demo assets: [open sea](https://unsplash.com/photos/a-sailboat-in-the-ocean-at-sunset-bAHMC9W2Di4), [cave](https://unsplash.com/photos/a-man-standing-in-a-cave-looking-out-at-the-water-n6PKibMAnsw), and [coast](https://unsplash.com/s/photos/mediterranean-sea). These URLs are host-owned demo data, not generated component input.

## Upstream reuse

The OpenUI adapter depends on `@openuidev/react-lang` and `@openuidev/react-ui` rather than copying their code. OpenUI is MIT-licensed; retain its copyright and license notice if its source is ever copied into this repository. Components copied from any other project need their own license review and attribution.
